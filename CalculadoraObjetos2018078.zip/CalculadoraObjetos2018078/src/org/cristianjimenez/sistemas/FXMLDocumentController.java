/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cristianjimenez.sistemas;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;


/**
 *
 * @author programacion
 */
public class FXMLDocumentController implements Initializable { 
    private boolean punto = true;
    float dato1,dato2, resultado;
    String cadena, ce;
    int op;
    @FXML Button btnMasMenos;
    @FXML Button btnCero;
    @FXML Button btnUno;
    @FXML Button btnPunto;
    @FXML Button btnIgual;
    @FXML Button btnDos;
    @FXML Button btnTres;
    @FXML Button btnSuma;
    @FXML Button btnCuatro;
    @FXML Button btnCinco;
    @FXML Button btnSeis;
    @FXML Button btnResta;
    @FXML Button btnSiete;
    @FXML Button btnOcho;
    @FXML Button btnNueve;
    @FXML Button btnMultiplicacion;
    @FXML Button btnCE;
    @FXML Button btnC;
    @FXML Button btnUnoX;
    @FXML Button btnDivision;
    @FXML Button btnPorcentaje;
    @FXML Button btnPotencia;
    @FXML Button btnRaiz;
    @FXML TextField txtValores;
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
        if(event.getSource()== btnUno)
        txtValores.setText(txtValores.getText()+ "1");
        else if(event.getSource()== btnDos)
        txtValores.setText(txtValores.getText()+ "2");
        else if(event.getSource()== btnTres)
        txtValores.setText(txtValores.getText()+ "3");
        else if(event.getSource()== btnCuatro)
        txtValores.setText(txtValores.getText()+ "4");
        else if(event.getSource()== btnCinco)
        txtValores.setText(txtValores.getText()+ "5");
        else if(event.getSource()== btnSeis)
        txtValores.setText(txtValores.getText()+ "6");
        else if(event.getSource()== btnSiete)
        txtValores.setText(txtValores.getText()+ "7");
        else if(event.getSource()== btnOcho)
        txtValores.setText(txtValores.getText()+ "8");
        else if(event.getSource()== btnNueve)
        txtValores.setText(txtValores.getText()+ "9");
        else if(event.getSource()== btnCero)
        txtValores.setText(txtValores.getText()+ "0");
        else if(event.getSource() == btnSuma){
            dato1 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            op = 1;
            }else if(event.getSource() == btnResta){
             dato1 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            op = 2;
            }else if(event.getSource() == btnMultiplicacion){
            dato1 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            op = 3;
            }else if(event.getSource() == btnDivision){
            dato1 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            op = 4;
            }else if(event.getSource() == btnPotencia){
            dato1 = Float.parseFloat(txtValores.getText());
            op = 5;
            }else if(event.getSource() == btnMasMenos){
            dato1 = Float.parseFloat(txtValores.getText());
            op = 6;
            }else if(event.getSource() == btnUnoX){
            dato1 = Float.parseFloat(txtValores.getText());
            op = 7;
            }else if(event.getSource() == btnPorcentaje){
            dato1 = Float.parseFloat(txtValores.getText());
            op = 8;
            }else if(event.getSource() == btnRaiz){
            dato1 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            txtValores.setText(String.valueOf(Math.sqrt(dato1)));
            } else if (event.getSource() == btnCE){
            String ce= txtValores.getText();
            if(ce.length() > 0){
            ce = ce.substring(0, ce.length()-1);
            txtValores.setText(ce);
            }
        } else if (event.getSource () == btnPunto){
            String cadena;
        cadena=txtValores.getText();
        if (cadena.length()<=0) {
            txtValores.setText("0.");
        }
        else{
            if (!existepunto(txtValores.getText())) {
                txtValores.setText(txtValores.getText()+".");
            }
        }
            }else if(event.getSource() == btnC){
            txtValores.setText("");
            }else if(event.getSource() == btnIgual){
            dato2 = Float.parseFloat(txtValores.getText());
            txtValores.setText("");
            
            
            switch(op){
                case 1:
                    resultado = dato1 + dato2;
                    txtValores.setText(String.valueOf(resultado));
                    break;
                case 2:
                    resultado = dato1 - dato2;
                    txtValores.setText(String.valueOf(resultado));
                    break;
                case 3:
                    resultado = dato1 * dato2;
                    txtValores.setText(String.valueOf(resultado));
                    break;
                case 4:
                    resultado = dato1 / dato2;
                    txtValores.setText(String.valueOf(resultado));
                    break;
                case 5:
                resultado = (dato1*dato1);
                txtValores.setText(String.valueOf(resultado));
                    break;
                case 6:
                resultado = ((-1)*dato1);
                txtValores.setText(String.valueOf(resultado));
                    break;
                case 7:
                resultado = ((1)/dato1);
                txtValores.setText(String.valueOf(resultado));
                    break;
                case 8:
                resultado = (dato1/100);
                txtValores.setText(String.valueOf(resultado));
                    break;
            }
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    private boolean existepunto(String cadena) {
    boolean punto;
        punto=false;
        
        for (int i = 0; i < cadena.length(); i++) {
            if (cadena.substring(i, i+1).equals(".")) {
                punto=true;
                break;
            }
            
        }
        return punto;    
    }
}
    




