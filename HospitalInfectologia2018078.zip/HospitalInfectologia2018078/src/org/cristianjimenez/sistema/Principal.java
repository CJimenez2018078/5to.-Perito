package org.cristianjimenez.sistema;

import java.io.InputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.cristianjimenez.controller.AreaController;
import org.cristianjimenez.controller.CargoController;
import org.cristianjimenez.controller.ContactoUrgenciaController;
import org.cristianjimenez.controller.EspecialidadController;
import org.cristianjimenez.controller.MedicoController;
import org.cristianjimenez.controller.MenuPrincipalController;
import org.cristianjimenez.controller.PacientesController;
import org.cristianjimenez.controller.ProgramadorController;
import org.cristianjimenez.controller.TelefonoMedicoController;


public class Principal extends Application {
    private final String PAQUETE_VISTA = "/org/cristianjimenez/view/";
    private Stage escenarioPrincipal;
    private Scene escena;
    @Override
    public void start(Stage escenarioPrincipal) {
       this.escenarioPrincipal = escenarioPrincipal;
       escenarioPrincipal.setTitle("Hospital de Infectologia");
       menuPrincipal();
       escenarioPrincipal.show();
    }
    
    public void menuPrincipal(){
        try{
            MenuPrincipalController menuPrincipal = (MenuPrincipalController)cambiarEscena("MenuPrincipalView.fxml",594,428);
            menuPrincipal.setEscenarioPrincipal(this);
        }catch(Exception e){
                e.printStackTrace();
        }
    }
     
    public void ventanaMedicos(){
        try{
            MedicoController medicoController = (MedicoController)cambiarEscena("MedicoView.fxml",761,603); 
            medicoController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaTelefonoMedico(){
        try{
            TelefonoMedicoController telefonoMedicoController = (TelefonoMedicoController)cambiarEscena("TelefonosMedicoView.fxml",474,501); 
            telefonoMedicoController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    
    public void ventanaPacientes(){
        try{
            PacientesController pacientesController = (PacientesController)cambiarEscena("PacientesView.fxml",877,747); 
            pacientesController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    
    public void ventanaContactoUrgencia(){
        try{
            ContactoUrgenciaController contactoUrgenciaController = (ContactoUrgenciaController)cambiarEscena("ContactoUrgenciaView.fxml",466,528);
            contactoUrgenciaController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    } 
    
    public void ventanaArea(){
        try{
            AreaController areaController = (AreaController)cambiarEscena("AreaView.fxml",376,379); 
            areaController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaCargo(){
        try{
            CargoController cargoController = (CargoController)cambiarEscena("CargoView.fxml",376,379); 
            cargoController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaEspecialidad(){
        try{
            EspecialidadController especialidadController = (EspecialidadController)cambiarEscena("EspecialidadView.fxml",447,436); 
            especialidadController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaProgramador(){
        try{
            ProgramadorController programadorController = (ProgramadorController)cambiarEscena("ProgramadorView.fxml",411,528); 
            programadorController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws Exception{//para que nos devuelva el verdadero error
           Initializable resultado = null;
           FXMLLoader cargadorFXML = new FXMLLoader();
           InputStream archivo = Principal.class.getResourceAsStream(PAQUETE_VISTA+fxml); // constante concatenado con fxml
           cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
           cargadorFXML.setLocation(Principal.class.getResource(PAQUETE_VISTA+fxml));
           escena = new Scene((AnchorPane)cargadorFXML.load(archivo),ancho,alto);
           escenarioPrincipal.setScene(escena);
           escenarioPrincipal.sizeToScene();
           resultado = (Initializable)cargadorFXML.getController();
           return resultado;
    }
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
